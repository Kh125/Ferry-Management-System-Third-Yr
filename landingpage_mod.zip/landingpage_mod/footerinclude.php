<footer class="site-footer" role="contentinfo">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-4 mb-5">
          <h3 class="mb-4">About FMS</h3>
          <p class="mb-5">Our intention is to provide convenient and easy ways to control and take care of your child (especially student) using new Technologies</p>
          <ul class="list-unstyled footer-link d-flex footer-social">
            <li><a href="#" class="p-2"><span class="fa fa-twitter"></span></a></li>
            <li><a href="#" class="p-2"><span class="fa fa-facebook"></span></a></li>
            <li><a href="#" class="p-2"><span class="fa fa-linkedin"></span></a></li>
            <li><a href="#" class="p-2"><span class="fa fa-instagram"></span></a></li>
          </ul>

        </div>
        <div class="col-md-5 mb-5 pl-md-5">
          <div class="mb-5">
            <h3 class="mb-4">Contact Info</h3>
            <ul class="list-unstyled footer-link">
              <li class="d-block">
                <span class="d-block">Address:</span>
                <span class="text-white">University of Information Technology, Parami Road, Hlaing Campus, Yangon, Myanmar</span>
              </li>
              <li class="d-block">
                <span class="d-block">Telephone:</span><span class="text-white">09-1234567</span>
              </li>
              <li class="d-block">
                <span class="d-block">Email:</span><span class="text-white">fms1235679@gmail.com</span>
              </li>
            </ul>
          </div>


        </div>
        <div class="col-md-3 mb-5">
          <h3 class="mb-4">Quick Links</h3>
          <ul class="list-unstyled footer-link">
            <li><a href="aboutlanding.php">About</a></li>
            <li><a href="schoollanding.php">School Info</a></li>
            <li><a href="feedbacklanding.php">Feedback</a></li>
            <li><a href="contactlanding.php">Contact</a></li>
          </ul>
        </div>
        <div class="col-md-3">

        </div>
      </div>
      <div class="row">
        <div class="col-12 text-md-center text-left">
          <p>            
            Copyright &copy;
            <script>document.write(new Date().getFullYear());</script> All Rights Reserved | Third Year Section-A Group                      
          </p>
        </div>
      </div>
    </div>
  </footer>
  <!-- END footer -->