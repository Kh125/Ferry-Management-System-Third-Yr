
<?php 
  if(isset($_GET['lang'])){
  include "lang_".$_GET['lang'].".php";
}

else{
  include "lang_en.php";
}
?>
<header role="banner">
    <nav class="navbar navbar-expand-lg  bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand " href="landingpage.php">FMS</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05"
          aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

   
        <div class="collapse navbar-collapse" id="navbarsExample05">
          <ul class="navbar-nav pl-md-5 ml-auto">
            <li class="nav-item">
              <a class="nav-link hmlanding" href="landingpage.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link abtlanding" href="aboutlanding.php">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link schlanding" href="schoollanding.php">School</a>
            </li>

            <!-- for dropdown li start -->
            <!-- <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="services.php" id="dropdown04" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">Services</a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
                <a class="dropdown-item" href="#"> </a>
                <a class="dropdown-item" href="#">Web Design</a>
                <a class="dropdown-item" href="#">App Design</a>
                <a class="dropdown-item" href="#">Start Up</a>
              </div>
            </li> -->

            <!-- for dropdown li end -->

            <li class="nav-item">
              <a class="nav-link" href="loginlanding.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="signuplanding.php">Signup</a>
            </li>
            <li class="nav-item">
              <a class="nav-link fblanding" href="feedbacklanding.php">Feedback</a>
            </li>
            <li class="nav-item">
              <a class="nav-link ctlanding" href="contactlanding.php">Contact</a>
            </li>

            <!-- language dropdown li start -->

            <li class="nav-item dropdown">
              <a href="#" onclick="return false;" class="nav-link dropdown-toggle" id="dropdown04" data-toggle="dropdown"
                >Services</a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
                <a class="dropdown-item" href="landingpage.php?lang=en">English</a>
                <a class="dropdown-item" href="landingpage.php?lang=pl">Myanmar</a>                
              </div>
            </li>

            <!-- language dropdown li end -->
          </ul>

          

        </div>
      </div>
    </nav>
  </header>