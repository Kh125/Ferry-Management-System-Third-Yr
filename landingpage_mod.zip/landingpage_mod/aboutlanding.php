<!doctype html>
<html lang="en">

<head>
  <title>Ferry Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Raleway:400,700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">


  <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">

  <!-- Theme Style -->
  <link rel="stylesheet" href="css/style.css">

</head>

<body>

  <?php 
  include("headerinclude.php");
  ?>
  <!-- END header -->

  <div class="inner-page">
    <div class="slider-item overlay" style="background-image: url('images/schoolbus1.jpg');" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row slider-text align-items-center justify-content-center">
          <div class="col-lg-9 text-center col-sm-12 element-animate">
            <h1 class="mb-4">About Us</h1>
            <p class="custom-breadcrumbs"><a href="landingpage.php">Home</a> <span class="mx-3">/</span> About</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php 
  include("whoweareinclude.php");
  ?>
  <!-- end who we are -->

  
  <div class="section">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-6 order-md-2">
          <figure class="img-dotted-bg">
            <img src="images/hero_2.jpg" alt="Image" class="img-fluid">
          </figure>
        </div>
        <div class="col-md-5 mr-auto">
          <h2 class="mb-4 section-title"><strong>Creativity</strong> Is Our Passion</h2>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi, quos, adipisci aliquid similique
            saepe ipsa minus maxime alias libero nam quis officia eum impedit. At quisquam reprehenderit cum hic enim?</p>
          <p>Necessitatibus eligendi molestias similique tempore, optio nobis numquam temporibus debitis cum aspernatur,
            eius, nihil soluta sapiente enim. Incidunt ipsam praesentium voluptate in pariatur dignissimos, ab corporis
            minima ea odio asperiores.</p>
  
        </div>
      </div>
    </div>
  </div>
  
  <div class="section">
    <div class="container">
      <div class="row justify-content-center mb-5 element-animate">
        <div class="col-md-8 text-center">
          <h2 class="mb-4 section-title">Meet Our <strong>Team</strong></h2>
          <p class="mb-5 lead">You can know about our team member and you can contact freely.</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4">
          <div class="media d-block media-custom text-center">
            <a href="#"><img src="images/cmk.jpg" alt="Image Placeholder" class="img-fluid" style="width:250px;height: 250px;"></a>
            <div class="media-body">
              <h3 class="mt-0 text-black">Chan Min Kyaw</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam minus repudiandae amet.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="media d-block media-custom text-center">
            <a href="#"><img src="images/hhh.jpg" alt="Image Placeholder" class="img-fluid" style="width:250px;height: 250px;"></a>
            <div class="media-body">
              <h3 class="mt-0 text-black">Hnin Htet Htet</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam minus repudiandae amet.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="media d-block media-custom text-center">
            <a href="#"><img src="images/igk.jpg" alt="Image Placeholder" class="img-fluid" style="width:250px;height: 250px;"></a>
            <div class="media-body">
              <h3 class="mt-0 text-black">Ingyin Khin</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam minus repudiandae amet.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="media d-block media-custom text-center">
            <a href="#"><img src="images/km.jpg" alt="Image Placeholder" class="img-fluid" style="width:250px;height: 250px;"></a>
            <div class="media-body">
              <h3 class="mt-0 text-black">Khant Hmuu</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam minus repudiandae amet.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="media d-block media-custom text-center">
            <a href="#"><img src="images/mmk.jpg" alt="Image Placeholder" class="img-fluid" style="width:250px;height: 250px;"></a>
            <div class="media-body">
              <h3 class="mt-0 text-black">Myo Myo Khant</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam minus repudiandae amet.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="media d-block media-custom text-center">
            <a href="#"><img src="images/vj.jpg" alt="Image Placeholder" class="img-fluid" style="width:250px;height: 250px;"></a>
            <div class="media-body">
              <h3 class="mt-0 text-black">Zayar Min Maung</h3>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam minus repudiandae amet.</p>
            </div>
          </div>
        </div>
  
      </div>
  
    </div>
  </div>
  <!-- END section -->



  <?php 
  include("footerinclude.php");
  ?>
  <!-- END footer -->

  <!-- loader -->
  <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
      <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
      <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
        stroke="#f4b214" /></svg></div>

  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/main.js"></script>

  <script type="text/javascript">
    
      $(".abtlanding").addClass("active");
      

  </script>
</body>

</html>