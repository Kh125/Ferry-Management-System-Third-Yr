<div class="section bg-light block-11">
    <div class="container">
      <div class="row justify-content-center mb-5">
        <div class="col-md-8 text-center">
          <h2 class="mb-4 section-title">Feedback</h2>
          <p>Response from clients who used our system for their convenience.</p>
        </div>
      </div>
      <div class="nonloop-block-11 owl-carousel">
        <div class="item">
          <div class="block-33 h-100">
            <div class="vcard d-flex mb-3">
              <div class="image align-self-center"><img src="images/person_1.jpg" alt="Person here"></div>
              <div class="name-text align-self-center">
                <h2 class="heading">U Aung Kyaw</h2>
                <span class="meta">Parent</span>
              </div>
            </div>
            <div class="text">
              <blockquote>
                <p>&rdquo; Good System.Really helpful for all parents.Especially for us who want to know everything about our children. &ldquo;</p>
              </blockquote>
            </div>
          </div>
        </div>
  
        <div class="item">
          <div class="block-33 h-100">
            <div class="vcard d-flex mb-3">
              <div class="image align-self-center"><img src="images/person_1.jpg" alt="Person here"></div>
              <div class="name-text align-self-center">
                <h2 class="heading">U Aye Min</h2>
                <span class="meta">Parent</span>
              </div>
            </div>
            <div class="text">
              <blockquote>
                <p>&rdquo; Good System.Really helpful for all parents.Especially for us who want to know everything about our children. &ldquo;</p>
              </blockquote>
            </div>
          </div>
        </div>


        <div class="item">
          <div class="block-33 h-100">
            <div class="vcard d-flex mb-3">
              <div class="image align-self-center"><img src="images/person_1.jpg" alt="Person here"></div>
              <div class="name-text align-self-center">
                <h2 class="heading">Daw Hnin Hnin</h2>
                <span class="meta">Parent</span>
              </div>
            </div>
            <div class="text">
              <blockquote>
                <p>&rdquo; Good System.Really helpful for all parents.Especially for us who want to know everything about our children. &ldquo;</p>
              </blockquote>
            </div>
          </div>
        </div>


        <div class="item">
          <div class="block-33 h-100">
            <div class="vcard d-flex mb-3">
              <div class="image align-self-center"><img src="images/person_1.jpg" alt="Person here"></div>
              <div class="name-text align-self-center">
                <h2 class="heading">U Min Lwin</h2>
                <span class="meta">Parent</span>
              </div>
            </div>
            <div class="text">
              <blockquote>
                <p>&rdquo; Good System.Really helpful for all parents.Especially for us who want to know everything about our children. &ldquo;</p>
              </blockquote>
            </div>
          </div>
        </div>


        <div class="item">
          <div class="block-33 h-100">
            <div class="vcard d-flex mb-3">
              <div class="image align-self-center"><img src="images/person_1.jpg" alt="Person here"></div>
              <div class="name-text align-self-center">
                <h2 class="heading">Daw Sandar</h2>
                <span class="meta">Parent</span>
              </div>
            </div>
            <div class="text">
              <blockquote>
                <p>&rdquo; Good System.Really helpful for all parents.Especially for us who want to know everything about our children. &ldquo;</p>
              </blockquote>
            </div>
          </div>
        </div>
  
      </div>
    </div>
  </div>