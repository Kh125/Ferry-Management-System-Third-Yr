<?php
define("_behs", "A.H.K");
define("_bems", "A.L.T");

define("_REGISTER", "စာရင်းသွင်းမည်");
define("_fname", "နာမည်ရှေ့စာလုံး");
define("_lname", "နာမည်နောက်စာလုံး");
define("_getstart", "စတင်မယ်");
define("_address", "လိပ္စာ");
define("_school", "ကျောင်းများ");
define("_all", "အားလုံး");
define("_yankin", "ရန်ကင်း");
define("_ahlone","အလုံ");
define("_botahtaung", "ဗိုလ်တထောင်");
define("_dagon", "ဒဂုံ");
define("_lanmadaw", "လမ်းမတော်");
define("_latha", "လသာ");
define("_mingalardon", "မင်္ဂလာဒုံ");
define("_pabedan", "ပန်းပဲတန်း");
define("_bahan", "ဗဟန်း");
define("_kamayut", "ကမာရွတ်");
define("_safety", "လုံခြုံမှု");
define("_comfort", "သက်တောင့်သက်သာ ရှိမှု");
define("_reliable", "ယုံကြည်ရမှု");
define("_easy", "လြယ္ကူမႈ");
define("_social", "လူဝင်ဆန့်ခြင်း");
define("_convenience", "အဆင်ပြေမှု");
define("_behs2sanchaung", "အထက (၂) စန်းချောင်း");
define("_phno", "09-123456");
define("_teammember", "Member များ");
define("_cmk", "ချမ်းမင်းကျော်");
define("_zy", "ဇေယျာမင်းမောင်");
define("_km", "ခန္႔မွဴး");
define("_igk", "အင်ကြင်းခင်");
define("_mmk", "မျိုးမျိုးခန့်");
define("_hhh", "နှင်းထက်ထက်");
define("_outclient", "ကျွန်တော်တို့၏ clients များ");
define("_contact", "ဆက်သွယ်ရန်");
define("_location", "တည်နေရာ");
define("_email", "အီးမေးလ်");
define("_sub", "Sub");
define("_message", "အကြောင်းအရာ");
define("_send", "ပို့မည်");
define("_onegivetrust", "သင့်ယုံကြည်မှုအတွက် အကောင်းဆုံးအရာ");
define("_werfms", "ကျွန်ုပ်တို့သည် FMS ဖြစ်ပါသည်");
define("_service", "ဝန်ဆောင်မှု");
define("_login", "ဝင်ရောက်မည်");
define("_setting", "ပြင်ဆင်ရန်");
define("_lang","ဘာသာစကား");
define("_myan","မြန်မာ");
define("_eng","အင်္ဂလိပ်");
?>










<!-- ကျွန်တော်တို့၏ ဝန်ဆောင်မှု
စန်းချောင်း
သင့်ကလေးကို တာဝန်ယူမှုအပြည့်နဲ့ ပို့ဆောင်ပေးမည့်သူ





ဆက်သွယ်ရန်


ဖုန်း

Message ပို့ရန်



ခေါင်းစဉ်


အသင်း


စာရင်းသွင်းမည် -->