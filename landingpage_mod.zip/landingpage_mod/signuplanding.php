<!doctype html>
<html lang="en">

<head>
  
  <title>Ferry Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Raleway:400,700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">


  <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">

  <!-- Theme Style -->
  <link rel="stylesheet" href="css/style.css">

  <style type="text/css">

  	body{
  		background: #ebeeef;
  	}

  	.signup{
  		position: relative;
  		width:700px;
  		height: 850px;
  		max-height: 850px;
  		margin: 0px auto;
  		background: #fff;
  		border-radius: 7px;
  		/*-webkit-box-shadow: 0px 0px 6px 0px rgba(0,0,0,0.7);
		-moz-box-shadow: 0px 0px 6px 0px rgba(0,0,0,0.7);
		box-shadow: 0px 0px 6px 0px rgba(0,0,0,0.7); */
		margin-top: 50px;


  	}

  	.signup .header{
  		width: 100%;
  		height: 200px;
  		display: block;
  		margin: 0px auto;
  		background-image: url(images/ferryschool.jpg);
  		background-position:50px -130px;
  		filter: blur(1px);
  	}

  	.headertxt{
  		
	  color: white;
	  font-weight: bold;
	  position: absolute;
	  top: 100px;
	  left: 50%;
	  transform: translate(-50%, -50%);
	  z-index: 2;
	  width: 100%;
	  height: 200px;	  
	  font-size:37px;
	  padding: 20px;
	  text-align: center;
	  line-height:150px;
	  /*background-color: rgb(0,0,0); */
	  background-color: rgba(54,84,99,0.7);
	  border-top-left-radius: 7px;
	  border-top-right-radius: 7px;
  	}

  	.signup span{
  		color: #808080;
  	}

  	.signup .content {
  		display: block;
  		width: 100%;
  		height: 650px;
  		margin: 0px auto;
  		background: #fff;
  		border-bottom-left-radius: 7px;
	  	border-bottom-right-radius: 7px;
  	}

  	.inpcon{
  		width: 100%;
  		height: 60px;
  		/*background: grey;*/
  		display: block;
  		margin: 0px auto;
  		margin-top: 10px;	
  	}

  	.inpcon:nth-child(1){
  		margin-top: 20px;
  	}

  	.labelsg{
  		float: left;
  		width: 35%;
  		height: 60px;
  		line-height: 60px;
  		text-align: center;
  		color: #808080;
  	}

  	.boxsg{
  		float: right;
  		width: 45%;
  		height: 60px;
  		margin-right: 20%;
  		border:none;
  		border-bottom: 1px solid grey;
  		outline: none;
  		color: #555555;
  	}

  	.butsg{
  		width: 100%;
  		height: 50px;
  		display: block;
  		/*background: grey;*/
  		margin-top: 30px;
  		margin-bottom: 20px;
  	}

  	.butsg .sgone{
  		display: block;
  		width: 150px;
  		height: 50px;
  		border:none;
  		box-shadow: none;
  		border-radius: 25px;
  		margin: 0px auto;
  		background: #57b846;
  		color: #fff;
  		transition: .6s;
  	}

  	.sgfile{
  		display: block;
  		width: 150px;
  		height: 60px;
  		border:none;
  		box-shadow: none;
  		/*border-radius: 25px;*/
  		/*margin: 0px auto;*/
  		background: #57b846;
  		color: #fff;
  		transition: .6s;
  		margin: 0px;
  		margin-left: 30px;
  		/*position: absolute;*/
  		outline: none;
  		line-height: 0px;
  	}

  	.butsg .sgone:hover,.sgfile:hover{
  		background: #222;
  		color:#fff;
  		transition: .6s;
  	}

  	/*.signup .hiddencontent{
  		display: block;
  		width: 100%;
  		height: 650px;
  		background: grey;
  		border-bottom-left-radius: 7px;
	  	border-bottom-right-radius: 7px;
  	}*/



  </style>

</head>

<body>

  	  <div class="signup">
  	  	
  	  		<div class="header">
  	  			
  	  		</div>

  	  		<div class="headertxt">
  	  			SIGNUP
  	  		</div>
  	  	<form method="post" action="aa.php">	
  	  		<div class="content">
  	  			<div class="inpcon">
	  	  			<div class="labelsg">Name
	  	  				<b style="color:red"> *</b>
	  	  			</div>
					<input type="text" name="name" placeholder="Name" class="boxsg">
  	  			</div>

  	  			<div class="inpcon">
	  	  			<div class="labelsg">Email<b style="color:red"> *</b></div>
					<input type="email" name="email" placeholder="Email" class="boxsg">
  	  			</div>

  	  			<div class="inpcon">
	  	  			<div class="labelsg">NRC<b style="color:red"> *</b></div>
					<input type="text" name="nrc" placeholder="NRC(eg.7/manyana(MNN)123456).." class="boxsg">
  	  			</div>

  	  			<div class="inpcon">
	  	  			<div class="labelsg">Address</div>
					<input type="text" name="address" placeholder="Address(No,Street,Block,Township)" class="boxsg">
  	  			</div>

  	  			<div class="inpcon">
	  	  			<div class="labelsg">Phone<b style="color:red"> *</b></div>
					<input type="telephone" name="phone" placeholder="Phone" class="boxsg">
  	  			</div>


  	  			<div class="inpcon">
					<div class="labelsg">DOB</div>
					<input type="date" name="dob" class="boxsg">
  	  			</div>

  	  			<div class="inpcon">
	  	  			<div class="labelsg">Owner Password<b style="color:red"> *</b></div>
					<input type="password" name="password" placeholder="Password" class="boxsg">
  	  			</div>

  	  			<div class="inpcon">
	  	  			<div class="labelsg">Confirm Password<b style="color:red"> *</b></div>
					<input type="password" name="cpassword" placeholder="Confirm Password" class="boxsg">
  	  			</div>

  	  			<div class="butsg">  	  
  	  				<a href="landingpage.php" style="margin-left: 10px;border-bottom: 1px solid #20c997;padding-bottom: 10px;"><i class="fa fa-long-arrow-left"></i>&nbsp;&nbsp;&nbsp;&nbsp;Back to FMS</a>				
					<button class="sgone" style="display: inline-block;margin-left: 20%;">Submit</button>

				</div>
				
  	  		</div>


  	  		<!-- <div class="hiddencontent">
  	  			
  	  			<div class="butsg">

					<button class="sgfile">
						<input type='file' name='photo' style="position:inline;outline: none;opacity:0;width: 150px;">Browse
							
					</button>
					
  	  			</div>

  	  		</div> -->


  	  	</form>
  	  </div>

	  <!-- loader -->
	  <div id="loader" class="show fullscreen">
	  	<svg class="circular" width="48px" height="48px">
		      <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
		      <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
		        stroke="#f4b214" />
    	</svg>
   	  </div>

  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/main.js"></script>

  <script type="text/javascript">
    
      $(".fblanding").addClass("active");
      
		
  </script>
</body>

</html>