<div class="section">
    <div class="container">



      <div class="row">

        <div class="col-md-12 text-center">
            <h2 class="mb-2 section-title">Contact Info</h2>
            <p class="mb-5">Got a question? We love to hear from you.Send us message and we'll respond as soon as possible.</p>
        </div>

        <div class="col-md-6 mb-5 order-2">
          <form action="#" method="post">
            <div class="row">

              

              <div class="col-md-6 form-group">
                <label for="name">Name</label>
                <input type="text" id="name" class="form-control ">
              </div>
              <div class="col-md-6 form-group">
                <label for="phone">Phone</label>
                <input type="text" id="phone" class="form-control ">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 form-group">
  
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 form-group">
                <label for="email">Email</label>
                <input type="email" id="email" class="form-control ">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 form-group">
                <label for="message">Write Message</label>
                <textarea name="message" id="message" class="form-control " cols="30" rows="8" style="resize: none;"></textarea>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 form-group">
                <input type="submit" value="Send Message" class="btn btn-primary px-3 py-3">
              </div>
            </div>
          </form>
        </div>
        <div class="col-md-6 order-2 mb-5">
          <div class="row justify-content-right">
            <div class="col-md-8 mx-auto contact-form-contact-info">
              <p class="d-flex">
                <span class="ion-ios-location icon mr-5"></span>
                <span>University of Information Technology, Parami Road, Hlaing Campus, Yangon, Myanmar</span>
              </p>
  
              <p class="d-flex">
                <span class="ion-ios-telephone icon mr-5"></span>
                <span>09-1234567</span>
              </p>
  
              <p class="d-flex">
                <span class="ion-android-mail icon mr-5"></span>
                <span>fms1235679@gmail.com</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>